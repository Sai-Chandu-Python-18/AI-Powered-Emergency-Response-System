import React, { useState } from 'react';
import { 
  Heart, 
  Shield, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Lightbulb,
  Activity,
  Settings,
  Smartphone,
  Cloud,
  BarChart3,
  Clock,
  User,
  Home,
  Zap,
  Watch,
  Radar,
  Phone,
  MapPin,
  Timer,
  Eye,
  Lock,
  FileText,
  Stethoscope,
  Wifi,
  Camera,
  MessageSquare,
  Navigation,
  X,
  Check,
  Minus
} from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('overview');

  const sections = [
    { id: 'overview', name: 'Document Overview', icon: FileText },
    { id: 'scope', name: 'Product Scope', icon: Target },
    { id: 'journey', name: 'User Stories & Workflows', icon: Users },
    { id: 'technical', name: 'Technical Requirements', icon: Settings },
    { id: 'metrics', name: 'Success Metrics', icon: BarChart3 },
    { id: 'risks', name: 'Risks & Mitigation', icon: AlertTriangle },
    { id: 'roadmap', name: 'Roadmap', icon: Calendar }
  ];

  const features = [
    {
      title: 'Wearable Integration',
      description: 'Syncs with guest-permitted smartwatches (e.g., Apple Watch, Fitbit) to monitor heart rate, SpO₂, fall detection.',
      benefit: 'Captures vitals without invasive devices.',
      icon: Watch,
      color: 'bg-blue-500'
    },
    {
      title: 'Room Sensors',
      description: 'Radar/thermal sensors detect falls, irregular movements (e.g., seizure convulsions).',
      benefit: 'Covers guests without wearables.',
      icon: Radar,
      color: 'bg-purple-500'
    },
    {
      title: 'Predictive Alerts',
      description: 'AI analyzes trends (e.g., spike in heart rate + plummeting SpO₂ → cardiac arrest risk).',
      benefit: 'Proactive intervention.',
      icon: Brain,
      color: 'bg-red-500'
    },
    {
      title: 'Medic Dispatch',
      description: 'Alerts on-site medical team via app/SMS with room number, vitals, and shortest path.',
      benefit: 'Reduces response time (<2 mins).',
      icon: Phone,
      color: 'bg-green-500'
    },
    {
      title: 'AI First-Aid Guide',
      description: 'Chatbot/video (AR overlay) instructs bystanders: "Begin CPR; defibrillator en route."',
      benefit: 'Empowers untrained staff.',
      icon: MessageSquare,
      color: 'bg-orange-500'
    }
  ];

  const outOfScope = [
    'Diagnosing conditions (only alerts based on predefined thresholds).',
    'Replacing 911/EMS (complements local emergency services).',
    'Storing long-term health data (only real-time processing).'
  ];

  const techStack = [
    {
      component: 'Wearable APIs',
      technology: 'Apple HealthKit, Google Fit, Withings',
      purpose: 'Pull heart rate, SpO₂, fall data.',
      icon: Watch,
      color: 'bg-blue-500'
    },
    {
      component: 'AI/ML Models',
      technology: 'LSTM networks (time-series anomaly detection), CNN for motion analysis',
      purpose: 'Predict strokes/seizures.',
      icon: Brain,
      color: 'bg-purple-500'
    },
    {
      component: 'Backend',
      technology: 'Apache Kafka (real-time data streams), Python (FastAPI)',
      purpose: 'Process sensor data.',
      icon: Cloud,
      color: 'bg-green-500'
    },
    {
      component: 'Frontend',
      technology: 'Medic PWA (Progressive Web App), Guest mobile app',
      purpose: 'Alerts and controls.',
      icon: Smartphone,
      color: 'bg-orange-500'
    },
    {
      component: 'Hardware',
      technology: 'Millimeter-wave radar (e.g., Infineon), Thermal cameras (non-invasive)',
      purpose: 'Fall/convulsion detection.',
      icon: Camera,
      color: 'bg-red-500'
    }
  ];

  const metrics = [
    { 
      name: 'Response Time', 
      target: '<90 seconds', 
      description: 'From detection to medic arrival',
      icon: Timer,
      color: 'bg-red-500'
    },
    { 
      name: 'False Positive Rate', 
      target: '<5%', 
      description: 'Via model tuning',
      icon: Brain,
      color: 'bg-blue-500'
    },
    { 
      name: 'Incident Resolution Rate', 
      target: '90%+', 
      description: '% of cases stabilized before EMS arrives',
      icon: CheckCircle,
      color: 'bg-green-500'
    }
  ];

  const risks = [
    {
      risk: 'False alarms causing panic.',
      mitigation: 'Multi-sensor validation (e.g., radar + wearable + audio distress detection).',
      impact: 'High',
      probability: 'Medium'
    },
    {
      risk: 'Guest privacy lawsuits.',
      mitigation: 'Clear opt-in workflows; granular data permissions.',
      impact: 'High',
      probability: 'Medium'
    },
    {
      risk: 'Hardware failures.',
      mitigation: 'Redundant sensors per room; nightly self-checks.',
      impact: 'High',
      probability: 'Low'
    }
  ];

  const roadmapPhases = [
    {
      phase: 'Phase 1',
      duration: '6 months',
      title: 'Pilot with wearables + basic fall detection in 10 rooms.',
      status: 'in-progress'
    },
    {
      phase: 'Phase 2', 
      duration: '12 months',
      title: 'Integrate predictive analytics (stroke/seizure models).',
      status: 'planned'
    },
    {
      phase: 'Phase 3',
      duration: '18 months', 
      title: 'AR first-aid guides + drone-defibrillator partnerships.',
      status: 'planned'
    }
  ];

  const stakeholders = [
    { role: 'Chief Medical Officer', responsibility: 'Validation' },
    { role: 'CTO', responsibility: 'Real-Time System Reliability' },
    { role: 'Legal', responsibility: 'Liability & Compliance' }
  ];

  const renderOverview = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">AI-Powered Emergency Response System</h1>
        <p className="text-xl text-gray-600 mb-8">For Hospitality Management (Real-Time Health Crisis Detection & Response)</p>
        <div className="flex justify-center space-x-4">
          <span className="px-4 py-2 bg-red-100 text-red-800 rounded-full font-medium">Emergency Response</span>
          <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-medium">AI Detection</span>
          <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full font-medium">Life-Saving</span>
        </div>
      </div>

      <div className="bg-gradient-to-r from-red-50 to-orange-50 p-8 rounded-xl border border-red-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">1.1 Purpose</h2>
        <p className="text-lg text-gray-700 leading-relaxed mb-8">
          This PRD defines the development of an AI-driven emergency response system that detects life-threatening health incidents (e.g., heart attacks, seizures) in hotel guests via wearable devices and room sensors, triggering instant alerts to on-site medical teams while providing guided first-aid support.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mb-6">1.2 Key Objectives</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900">Early Detection</h3>
              <p className="text-gray-600 text-sm">Identify critical health anomalies in real time</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900">Rapid Response</h3>
              <p className="text-gray-600 text-sm">Automatically alert medics with guest location/vitals</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900">First-Aid Support</h3>
              <p className="text-gray-600 text-sm">AI chatbot/video guides bystanders or staff</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900">Privacy-Centric</h3>
              <p className="text-gray-600 text-sm">Opt-in only; no continuous monitoring without consent</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Heart className="w-8 h-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-900">24/7</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Health Monitoring</h3>
          <p className="text-sm text-gray-600">Continuous vital signs and anomaly detection</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Timer className="w-8 h-8 text-blue-500" />
            <span className="text-2xl font-bold text-gray-900">&lt;90s</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Response Time</h3>
          <p className="text-sm text-gray-600">From detection to medic arrival</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Brain className="w-8 h-8 text-purple-500" />
            <span className="text-2xl font-bold text-gray-900">AI</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Predictive</h3>
          <p className="text-sm text-gray-600">Early warning system for critical events</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Shield className="w-8 h-8 text-green-500" />
            <span className="text-2xl font-bold text-gray-900">HIPAA</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Privacy First</h3>
          <p className="text-sm text-gray-600">Compliant and secure data handling</p>
        </div>
      </div>
    </div>
  );

  const renderScope = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">2. Product Scope</h2>
        <p className="text-lg text-gray-600">Features, functionality, and system boundaries</p>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">2.1 Features & Functionality</h3>
        <div className="space-y-6">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div key={index} className="border-l-4 border-gray-200 pl-6 hover:border-red-300 transition-colors">
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-lg ${feature.color} flex-shrink-0`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h4>
                    <p className="text-gray-600 mb-3">{feature.description}</p>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-green-600">User Benefit:</span>
                      <span className="text-sm text-gray-700">{feature.benefit}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-red-50 p-8 rounded-xl border border-red-200">
        <h3 className="text-2xl font-bold text-red-800 mb-6 flex items-center">
          <X className="w-6 h-6 mr-3" />
          2.2 Out of Scope
        </h3>
        <div className="space-y-4">
          {outOfScope.map((item, index) => (
            <div key={index} className="flex items-start space-x-3">
              <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
              <span className="text-red-700">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderJourney = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">3. User Stories & Workflows</h2>
        <p className="text-lg text-gray-600">Guest and staff experience workflows</p>
      </div>

      <div className="space-y-8">
        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <User className="w-7 h-7 mr-3 text-blue-500" />
            3.1 Guest Journey
          </h3>
          
          <div className="space-y-8">
            <div className="border-l-4 border-blue-300 pl-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Opt-In During Check-In:</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-blue-600 font-semibold text-xs">1</span>
                  </div>
                  <p className="text-gray-700">Guest consents to share wearable data or enable room sensors.</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-blue-600 font-semibold text-xs">2</span>
                  </div>
                  <p className="text-gray-700">Selects conditions to monitor (e.g., "I have epilepsy; detect seizures.").</p>
                </div>
              </div>
            </div>

            <div className="border-l-4 border-red-300 pl-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Emergency Detection:</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-red-600 font-semibold text-xs">1</span>
                  </div>
                  <p className="text-gray-700">AI detects seizure-like movements via room radar → verifies with wearable data (elevated heart rate).</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-red-600 font-semibold text-xs">2</span>
                  </div>
                  <p className="text-gray-700">Alerts medic: "Room 1410: Possible seizure. Vitals spiking at 98% confidence."</p>
                </div>
              </div>
            </div>

            <div className="border-l-4 border-purple-300 pl-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Post-Incident:</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-purple-600 font-semibold text-xs">1</span>
                  </div>
                  <p className="text-gray-700">System logs anonymized incident data for improvement.</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-purple-600 font-semibold text-xs">2</span>
                  </div>
                  <p className="text-gray-700">Guest can request report for personal physician.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Stethoscope className="w-7 h-7 mr-3 text-green-500" />
            3.2 Staff Workflow
          </h3>
          
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <BarChart3 className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Medic Dashboard</h4>
                <p className="text-gray-600">Real-time map of alerts with priority levels.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Brain className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">AI Co-Pilot</h4>
                <p className="text-gray-600">Suggests actions (e.g., "Bring defibrillator; guest has history of arrhythmia.").</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTechnical = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">4. Technical Requirements</h2>
        <p className="text-lg text-gray-600">System architecture and technology stack</p>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">4.1 Tech Stack</h3>
        <div className="space-y-6">
          {techStack.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-lg ${item.color} flex-shrink-0`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">{item.component}</h4>
                    <p className="text-gray-600 mb-2">{item.technology}</p>
                    <p className="text-sm text-gray-500">{item.purpose}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-xl border border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
          <Shield className="w-7 h-7 mr-3 text-red-500" />
          4.2 Data & Compliance
        </h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <Lock className="w-6 h-6 text-blue-500" />
              <h4 className="font-semibold text-gray-900">Encryption</h4>
            </div>
            <p className="text-sm text-gray-600">End-to-end TLS 1.3 for vitals transmission.</p>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <FileText className="w-6 h-6 text-green-500" />
              <h4 className="font-semibold text-gray-900">Compliance</h4>
            </div>
            <p className="text-sm text-gray-600">HIPAA (if US-based), GDPR (EU), explicit guest consent.</p>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <Clock className="w-6 h-6 text-purple-500" />
              <h4 className="font-semibold text-gray-900">Data Retention</h4>
            </div>
            <p className="text-sm text-gray-600">Anonymize after 24hrs; store only metadata (e.g., "seizure incident, response time: 1m 42s").</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMetrics = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">5. Success Metrics (KPIs)</h2>
        <p className="text-lg text-gray-600">Key performance indicators and targets</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {metrics.map((metric, index) => {
          const IconComponent = metric.icon;
          return (
            <div key={index} className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center">
              <div className={`w-16 h-16 ${metric.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <IconComponent className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{metric.name}</h3>
              <div className="text-3xl font-bold text-gray-900 mb-2">{metric.target}</div>
              <p className="text-sm text-gray-600">{metric.description}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-xl border border-blue-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp className="w-6 h-6 mr-2 text-blue-600" />
          Additional Success Indicators
        </h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span className="text-gray-700">System uptime: 99.9%+</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span className="text-gray-700">Guest satisfaction with emergency response</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span className="text-gray-700">Staff confidence in using the system</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span className="text-gray-700">Reduction in emergency response costs</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRisks = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">6. Risks & Mitigation</h2>
        <p className="text-lg text-gray-600">Identified risks and mitigation strategies</p>
      </div>

      <div className="space-y-6">
        {risks.map((risk, index) => (
          <div key={index} className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{risk.risk}</h3>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600">Impact:</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      risk.impact === 'High' ? 'bg-red-100 text-red-800' :
                      risk.impact === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.impact}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600">Probability:</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      risk.probability === 'High' ? 'bg-red-100 text-red-800' :
                      risk.probability === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.probability}
                    </span>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Mitigation Strategy:</h4>
                  <p className="text-gray-700">{risk.mitigation}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderRoadmap = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">7. Roadmap</h2>
        <p className="text-lg text-gray-600">Development timeline and milestones</p>
      </div>

      <div className="space-y-6">
        {roadmapPhases.map((phase, index) => (
          <div key={index} className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-start space-x-6">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 ${
                phase.status === 'completed' ? 'bg-green-500' :
                phase.status === 'in-progress' ? 'bg-blue-500' :
                'bg-gray-400'
              }`}>
                <span className="text-white font-bold text-lg">{index + 1}</span>
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-4 mb-3">
                  <h3 className="text-2xl font-bold text-gray-900">{phase.phase}</h3>
                  <span className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full font-medium">
                    {phase.duration}
                  </span>
                  <span className={`px-4 py-2 rounded-full font-medium ${
                    phase.status === 'completed' ? 'bg-green-100 text-green-800' :
                    phase.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {phase.status === 'completed' ? 'Completed' :
                     phase.status === 'in-progress' ? 'In Progress' : 'Planned'}
                  </span>
                </div>
                <p className="text-lg text-gray-700">{phase.title}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">Approval</h3>
        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Stakeholders:</h4>
          <div className="grid md:grid-cols-3 gap-4">
            {stakeholders.map((stakeholder, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-semibold text-gray-900">{stakeholder.role}</h5>
                <p className="text-sm text-gray-600">({stakeholder.responsibility})</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">PRD Version: <span className="font-semibold">1.0</span></p>
              <p className="text-sm text-gray-600">Status: <span className="font-semibold text-orange-600">Draft (Review Pending)</span></p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Last Updated: {new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview': return renderOverview();
      case 'scope': return renderScope();
      case 'journey': return renderJourney();
      case 'technical': return renderTechnical();
      case 'metrics': return renderMetrics();
      case 'risks': return renderRisks();
      case 'roadmap': return renderRoadmap();
      default: return renderOverview();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-orange-600 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AI-Powered Emergency Response System</h1>
                <p className="text-sm text-gray-600">Product Requirements Document</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                Version 1.0
              </span>
              <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                Draft (Review Pending)
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Navigation */}
          <nav className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 sticky top-8">
              <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-4">Sections</h2>
              <ul className="space-y-2">
                {sections.map((section) => {
                  const IconComponent = section.icon;
                  return (
                    <li key={section.id}>
                      <button
                        onClick={() => setActiveSection(section.id)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          activeSection === section.id
                            ? 'bg-red-100 text-red-700'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <IconComponent className="w-5 h-5" />
                        <span className="font-medium text-sm">{section.name}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-1">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;